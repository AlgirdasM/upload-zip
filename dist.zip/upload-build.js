"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.uploadBuild = void 0;
const axios_1 = __importDefault(require("axios"));
const form_data_1 = __importDefault(require("form-data"));
const fs_1 = __importDefault(require("fs"));
const constants_1 = require("./constants");
const jsonKeyRegex = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/;
const uploadBuild = ({ url, additionalFormData, additionalHeaders, filePath = `./${constants_1.DEFAULT_FILENAME}`, fileKey = constants_1.DEFAULT_FILE_KEY, method = constants_1.DEFAULT_METHOD, }) => __awaiter(void 0, void 0, void 0, function* () {
    const formData = new form_data_1.default();
    const file = fs_1.default.createReadStream(filePath);
    const generatedHeaders = {};
    if (!jsonKeyRegex.test(fileKey)) {
        throw new Error('fileKey is invalid');
    }
    formData.append(fileKey, file);
    if (Array.isArray(additionalFormData)) {
        additionalFormData.forEach(data => {
            const value = data.split(':');
            if (value.length !== 2) {
                throw new Error('additionalFormData is invalid');
            }
            formData.append(value[0], value[1]);
        });
    }
    if (Array.isArray(additionalHeaders)) {
        additionalHeaders.forEach(data => {
            const value = data.split(':');
            if (value.length !== 2) {
                throw new Error('additionalHeaders is invalid');
            }
            generatedHeaders[value[0]] = value[1];
        });
    }
    console.log(additionalHeaders);
    file.on('error', error => {
        throw error;
    });
    file.on('open', () => {
        formData.getLength((error, length) => {
            if (error) {
                throw error;
            }
            const headers = Object.assign(Object.assign(Object.assign({}, generatedHeaders), formData.getHeaders()), { 'Content-Length': length });
            if (method === 'post') {
                axios_1.default
                    .post(url, formData, { headers })
                    .then(response => {
                    console.log(response.data);
                })
                    .catch(error => {
                    throw error;
                });
            }
            else {
                axios_1.default
                    .put(url, formData, { headers })
                    .then(response => {
                    console.log(response.data);
                })
                    .catch(error => {
                    throw error;
                });
            }
        });
    });
});
exports.uploadBuild = uploadBuild;
