# upload-zip

A Node.js library that archives a directory to a ZIP file and uploads the ZIP file to an API.

## How to use it

Install library with npm(or other node package manager) `npm install upload-zip --save-dev`
and use it for example like this: `upload-zip --url http://localhost:8080/api/file --additionalHeaders `

## Additional Headers and Additional Form Data
There properties are separated by key:value string.
For example to pass 

## Available options

```
  --help                Show help                                      [boolean]
  --version             Show version number                            [boolean]
  --url                 The URL to send the file to                     [string] [required]
  --fileKey              The key to use for the file in the form data    [string] [default: "file"]
  --additionalFormData  Additional form data to send with the file      [array]
  --additionalHeaders   Additional headers to send with the request    [array]
  --fileName             The file name to save archived data to          [string] [default: "dist.zip"]
  --folderPath          The folder path to compress                    [string] [default: "dist"]
```

## Develop

When developing create branch from develop and create pull request to it. After merging to develop, it will create alpha version.

## Release

Releases are based on semantic version. After release develop will be bumped by one patch release - as a smallest increment possible.
To make a release update develop branch with:

```
npm run release:major
npm run release:minor
npm run release:patch
```

Depending on changes. Create pull request to main branch and merge.
