import { Method } from './types';
export declare const DEFAULT_FOLDER_PATH = "dist";
export declare const DEFAULT_FILENAME = "dist.zip";
export declare const DEFAULT_FILE_KEY = "file";
export declare const DEFAULT_METHOD: Method;
