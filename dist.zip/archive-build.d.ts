export interface ArchiveBuildParams {
    folderPath?: string;
    fileName?: string;
}
export declare const archiveBuild: ({ folderPath, fileName, }: ArchiveBuildParams) => Promise<{
    folderPath: string;
    fileName: string;
}>;
