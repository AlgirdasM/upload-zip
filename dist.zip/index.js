#!/usr/bin/env node
"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const yargs_1 = __importDefault(require("yargs"));
const upload_build_1 = require("./upload-build");
const archive_build_1 = require("./archive-build");
const constants_1 = require("./constants");
const parser = (0, yargs_1.default)(process.argv.slice(2))
    .option('url', {
    description: 'The URL to send the file to',
    type: 'string',
    demandOption: true,
})
    .option('method', {
    description: 'Method to use POST or PUT',
    type: 'string',
    default: constants_1.DEFAULT_METHOD,
})
    .option('fileKey', {
    description: 'The key to use for the file in the form data',
    type: 'string',
    default: constants_1.DEFAULT_FILE_KEY,
})
    .option('additionalFormData', {
    description: 'Additional form data to send with the file',
    type: 'array',
})
    .option('additionalHeaders', {
    description: 'Additional headers to send with the request',
    type: 'array',
})
    .option('fileName', {
    description: 'The file name to save archived data to',
    type: 'string',
    default: constants_1.DEFAULT_FILENAME,
})
    .option('folderPath', {
    description: 'The folder path to compress',
    type: 'string',
    default: constants_1.DEFAULT_FOLDER_PATH,
});
(() => __awaiter(void 0, void 0, void 0, function* () {
    try {
        const argv = yield parser.argv;
        if (!argv.url) {
            console.error('Error: url key is missing');
            return;
        }
        if (!['post', 'put'].includes(argv.method)) {
            console.error('Error: we support only post or put method');
            return;
        }
        const { fileName } = yield (0, archive_build_1.archiveBuild)({
            folderPath: argv.folderPath,
            fileName: argv.fileName,
        });
        yield (0, upload_build_1.uploadBuild)({
            url: argv.url,
            fileKey: argv.fileKey,
            filePath: fileName,
            additionalFormData: argv.additionalFormData,
            additionalHeaders: argv.additionalHeaders,
            method: argv.method,
        });
    }
    catch (e) {
        console.error(e);
    }
}))();
