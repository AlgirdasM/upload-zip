"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_METHOD = exports.DEFAULT_FILE_KEY = exports.DEFAULT_FILENAME = exports.DEFAULT_FOLDER_PATH = void 0;
exports.DEFAULT_FOLDER_PATH = 'dist';
exports.DEFAULT_FILENAME = 'dist.zip';
exports.DEFAULT_FILE_KEY = 'file';
exports.DEFAULT_METHOD = 'post';
