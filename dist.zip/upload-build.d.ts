import { Method } from './types';
export interface UploadBuildParams {
    url: string;
    method?: Method;
    filePath?: string;
    fileKey?: string;
    additionalFormData?: string[];
    additionalHeaders?: string[];
}
export declare const uploadBuild: ({ url, additionalFormData, additionalHeaders, filePath, fileKey, method, }: UploadBuildParams) => Promise<void>;
