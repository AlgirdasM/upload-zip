export type Method = 'post' | 'put';
