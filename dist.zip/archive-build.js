"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.archiveBuild = void 0;
const fs_1 = __importDefault(require("fs"));
const archiver_1 = __importDefault(require("archiver"));
const constants_1 = require("./constants");
const archive = ({ folderPath = constants_1.DEFAULT_FOLDER_PATH, fileName = constants_1.DEFAULT_FILENAME }) => __awaiter(void 0, void 0, void 0, function* () {
    const output = fs_1.default.createWriteStream(fileName);
    const archive = (0, archiver_1.default)('zip', { zlib: { level: 9 } });
    archive.pipe(output);
    archive.directory(folderPath, false);
    yield archive.finalize();
    return {
        folderPath,
        fileName,
    };
});
const archiveBuild = ({ folderPath = constants_1.DEFAULT_FOLDER_PATH, fileName = constants_1.DEFAULT_FILENAME, }) => __awaiter(void 0, void 0, void 0, function* () {
    fs_1.default.stat(folderPath, (err, stats) => {
        if (err) {
            throw new Error(`${folderPath} does not exist`);
        }
        else if (stats.isDirectory()) {
            console.info(`${folderPath} is a directory, archiving`);
        }
        else {
            throw new Error(`${folderPath} is not a directory`);
        }
    });
    return archive({
        folderPath,
        fileName,
    });
});
exports.archiveBuild = archiveBuild;
